---
name: doc-converter
description: Convert documents between PDF, Word (.docx) and Markdown (.md) without losing major information - text, headings, tables, images/figures and equations are carried across and then verified. Use this skill whenever the user wants a file changed from one of these formats to another, in any wording - "convert this PDF to Word", "turn this paper into markdown", "make this PDF editable", "export my essay as PDF", "get this lecture PDF into Notion/notes", "extract this scanned PDF", "轉做 Word / PDF / md" - including scanned or image-only PDFs, journal articles, lecture slides, figure-heavy guides, plain-text (.txt) transcripts and the user's own assignments, even if they only attach a file and name the target format.
---

# Document converter (PDF / DOCX / Markdown)

Convert a document between PDF, Word and Markdown so that nothing important goes missing. "Important" means: all of the text in every language, the heading structure, every table (as a real table), every figure/image (with its caption), every equation (readable, and editable where the target allows), and small state such as ticked checkboxes. Fonts, colours, exact page layout and running headers/footers are not important and may change.

The reason this skill exists is that every converter fails silently somewhere - equations vanish, a table becomes loose numbers, a figure is skipped, Chinese text disappears from a PDF, a ticked box loses its tick - and the output still looks plausible. So the workflow is always: **convert with the right route, then verify, then repair**. Never hand back a conversion that has not been checked.

## Workflow

1. **Look at the source.** Identify the format, length, and whether it has tables, figures, equations, non-English text, form fields, or is scanned. Render it and look at a few pages (see "Looking at pages") - the look of the page is the ground truth the output is compared against, because the tools that read the source can themselves miss things.
2. **Convert** using the route for that direction below.
3. **Verify** with `losscheck.py` plus the visual checks under "Verify".
4. **Repair** anything lost, and re-check.
5. **Deliver** the file with its media folder if it has one. Report quietly: say nothing about the checks when everything survived; if something could not be preserved or had to change, say exactly what and where in one or two lines (e.g. "Equation 3 on p.4 is kept as an image, not editable text").

Keep the output beside the source with the same base name (`paper.pdf` -> `paper.md` + `paper_media/`). Never overwrite the source. Convert, do not edit: keep the author's wording, punctuation and order even when it could be improved, unless asked.

## Tools

Check what is present (`which pandoc soffice pdftoppm pdffonts tesseract`; `python3 -c "import pymupdf4llm"`) and install what is missing: `pip install --break-system-packages pymupdf pymupdf4llm pdf2docx`. Find Chromium with `CHROME=$(ls /opt/pw-browsers/chromium-*/chrome-linux/chrome 2>/dev/null | head -1 || which chromium chromium-browser google-chrome)`.

The helper scripts (`losscheck.py`, `docx_prep.py`, `figcrop.py`, `print.css`) are in the `scripts/` folder beside this file. Set `SKILL` to the folder that contains this SKILL.md and call them as `"$SKILL/scripts/..."`; there is no need to read their source unless one fails.

Two environment facts that cause silent loss, so test rather than assume:
- **LibreOffice without its Math module drops every Word equation** when exporting to PDF (the line simply has a gap). Check with `ls /usr/lib/libreoffice/program/libsmlo.so`.
- **Pandoc's LaTeX PDF engine is often incomplete** (missing packages, no CJK fonts). Do not rely on it; use the HTML -> Chromium route below.

## Routes

### Word -> Markdown

Pandoc does the conversion, but it silently ignores several things Word files contain. Run the pre-check first; it reports them and writes a copy in which form checkboxes become plain `☐`/`☒` text so their state survives.

```bash
python3 "$SKILL/scripts/docx_prep.py" in.docx in_prepped.docx
pandoc in_prepped.docx -s -t gfm+tex_math_dollars --wrap=none --extract-media=in_media -o in.md
```

Act on what the pre-check reports: text in text boxes has to be pulled from `word/document.xml` and placed where it sits on the page; charts and SmartArt have no image inside the file, so render the page (Word -> PDF) and crop them; tracked changes are accepted by default (mention it); comments are dropped unless the user wants them (`--track-changes=all`); a header/footer that holds real content (a name, a student ID) should be added once at the top.

Then tidy the Markdown so its structure matches how the document looks, not how it happened to be formatted:

- `-s` keeps a Title-styled title as front matter. If the title is only big bold text, it arrives as a bold paragraph: make it the single `#` heading and move the real section headings down one level.
- Strip bold markers pandoc leaves inside headings (`# **Methods**` -> `## Methods`).
- Indented paragraphs arrive as `>` block quotes. Keep the quote only where the text is a quotation or call-out; turn indented checklist lines into task lists (`☐ item` -> `- [ ] item`, `☒ item` -> `- [x] item`) and other indented lines into plain paragraphs or list items.
- Equations become LaTeX in `$...$` / `$$...$$`; footnotes become `[^1]` notes.
- Simple tables become pipe tables. Tables with merged cells come out as HTML `<table>` blocks - keep them as HTML, because a pipe table cannot express merged cells and flattening them scrambles the data.
- Images come out as `<img ...>` tags; rewrite them to `![alt](path)`:
  ```bash
  python3 -c "import re,sys;p=sys.argv[1];s=open(p).read();s=re.sub(r'<img src=\"([^\"]+)\"[^>]*?alt=\"([^\"]*)\"[^>]*/>',r'![\2](\1)',s);s=re.sub(r'<img src=\"([^\"]+)\"[^>]*/>',r'![](\1)',s);open(p,'w').write(s)" in.md
  ```
- Pandoc sometimes repeats a table caption above and below the table; delete the duplicate.
- Colour and highlighting are lost. If colour carries meaning that is not also in the words (e.g. red = marker's comment with no label), add a short label rather than losing the distinction.

### Markdown -> Word

```bash
pandoc in.md -o in.docx --resource-path="$(dirname in.md)"
```

LaTeX maths becomes native, editable Word equations; pipe tables become Word tables; task lists become checkbox lines; images are embedded. If the user has a template, add `--reference-doc=template.docx`. If an image path is broken pandoc only warns - read the warnings, a missing figure is a major loss.

Pandoc turns an image's alt text into a visible caption. When the Markdown already has the caption or heading as its own line next to the image (as files produced by this skill from PDFs do), add `-f markdown-implicit_figures`, otherwise every figure gets its caption twice.

### Markdown -> PDF

Go through HTML and print with Chromium; it renders equations (MathML), tables, images and Chinese/Japanese/Korean text reliably.

```bash
pandoc in.md -s --mathml --embed-resources --metadata pagetitle="in" --resource-path="$(dirname in.md)" -c "$SKILL/scripts/print.css" -o in.html
"$CHROME" --headless --no-sandbox --disable-gpu --no-pdf-header-footer \
  --print-to-pdf=in.pdf "file://$(realpath in.html)" 2>/dev/null
```

`print.css` sets A4 pages and the fonts. Keep a Latin font ahead of the CJK font in its `font-family`: if the CJK font comes first, curly quotes and apostrophes are drawn full-width (`group' s`). Add `-f markdown-implicit_figures` under the same condition as for Word.

### Word -> PDF

First count the equations: `unzip -p in.docx word/document.xml | grep -o "<m:oMath" | wc -l`.

- **No equations, or LibreOffice has its Math module** -> `soffice --headless --convert-to pdf --outdir . in.docx`. This keeps the Word layout, including form checkboxes.
- **Equations present and no Math module** -> LibreOffice would silently drop them. Use `pandoc in_prepped.docx -s --mathml --embed-resources --extract-media=in_media -c "$SKILL/scripts/print.css" -o in.html` (after `docx_prep.py`), then print with Chromium as above. The layout becomes plain, but nothing is lost. Tell the user in one line that the layout was simplified to keep the equations.
- If the session is linked to the user's computer and a Word export tool is available there, that gives the most faithful PDF; prefer it for a final assignment submission.

Either way, rasterise the result and look at any page that should contain an equation.

### Plain text (.txt) -> anything

A text file is not Markdown: pandoc would merge its lines into one paragraph and treat stray `*`, `_`, `#` or `<` as formatting. Turn it into Markdown first - normalise line endings, make each non-empty line its own paragraph (for hard-wrapped text, join lines within a block and split on blank lines), backslash-escape Markdown's special characters, and bold obvious labels such as `SPEAKER 0` - then use the Markdown routes. Do not add headings, split long paragraphs or clean up a transcript's wording unless asked; that is editing, so offer it instead.

### PDF -> Markdown

**First decide whether the text layer can be trusted.** A PDF can look perfect and still hold text that is absent, incomplete or scrambled.

```bash
python3 -c "import pymupdf,sys;d=pymupdf.open(sys.argv[1]);print(len(d),'pages; chars/page:',[len(p.get_text().strip()) for p in d][:40]);print(d[min(1,len(d)-1)].get_text()[:600])" in.pdf
pdffonts in.pdf | head -15
```

- Almost no characters per page -> scanned; see "Scanned PDFs".
- Read the printed sample against the page image. If words on the page are missing from it, it is scrambled, or one script is gone (typically Latin text present and all the Chinese missing), the layer is unreliable. Fonts listed by `pdffonts` with `uni` = `no` and a `Custom` or `Identity` encoding are the usual cause (Type 3 fonts from plotting libraries, some LaTeX and print-to-PDF output). Treat the affected text as scanned: transcribe it from the page images. The parts of the layer that are correct still help - use them, and the word positions, to cross-check what you typed.

For a PDF with a sound text layer, extract (run from the output folder so image links are relative):

```bash
python3 -c "
import pymupdf4llm, sys, pathlib
src, stem = sys.argv[1], pathlib.Path(sys.argv[1]).stem
md = pymupdf4llm.to_markdown(src, write_images=True, image_path=stem + '_media', dpi=200)
pathlib.Path(stem + '.md').write_text(md)" in.pdf
```

That output is a first draft, not the result. Compare it against the page images and repair:

- **Equations** are the main casualty: they arrive as scrambled symbols, or not at all. Look at each page that has maths and retype every equation as LaTeX (`$...$` inline, `$$...$$` display), keeping equation numbers. Sometimes a whole paragraph containing maths is exported as a picture instead of text; retype the paragraph and remove the picture. This also applies to chemical formulas and anything with sub/superscripts (`CO<sub>2</sub>` or `$\mathrm{CO_2}$`).
- **Tables**: check each against the page - right number of rows and columns, numbers in the right cells, header row intact, units and footnote markers kept. Tables without ruled lines are often missed entirely and appear as loose lines of text; rebuild them as pipe tables. Use an HTML table for merged cells.
- **Figures**: embedded photos are exported, but charts and diagrams drawn as vector graphics are skipped or shredded into fragments, and their axis labels get dumped into the body text. Crop each one from the rendered page as a single image (see "Cropping figures") and delete the stray label text: words that belong to a figure stay inside the figure. Put the caption directly under the image as its own line.
- **Headings**: fix levels so they follow the document's real outline (one `#` title, `##` sections, ...) and strip stray bold markers from heading text. Do not invent headings the document does not have.
- **Reading order**: in two-column articles check that columns were not interleaved and that a figure or footnote did not split a sentence.
- **Noise**: remove running headers/footers and page numbers; rejoin words hyphenated across lines. Keep footnotes, and keep the reference list complete.
- **Slides and figure-heavy guides**: one heading per slide or panel (its title), its text as paragraphs or bullets, and every chart or diagram kept as an image. For these documents the extractor's draft is usually not worth repairing: build the Markdown directly from the page images and crops.

### Cropping figures

`scripts/figcrop.py` crops a page region to a PNG and logs the region in `figures.json`, which lets the check ignore words that live inside figures. Coordinates are PDF points with the origin at the top left.

```bash
python3 "$SKILL/scripts/figcrop.py" in.pdf PAGE X0 Y0 X1 Y1 in_media/fig1.png
```

Find the region from the text around the figure rather than by guessing: `page.get_text("dict")` gives the position and font size of every text span (positions are right even when the characters are not), so a figure runs from the bottom of the paragraph or heading above it to the top of its caption or the next heading. When pages share one layout, work the boxes out once and loop. Look at a few crops afterwards: nothing cut off (legends and axis titles often sit outside the plot area), and no body text caught at the edges.

### PDF -> Word

Default: produce the clean Markdown as above (with repairs), then convert Markdown -> Word. This gives real heading styles, real tables and editable equations, which is what "make this PDF editable" usually means.

Only when the user wants the page to *look* like the original (forms, posters, designed layouts) use the layout-preserving converter instead:

```bash
python3 -c "
from pdf2docx import Converter; import sys
c = Converter(sys.argv[1]); c.convert(sys.argv[2]); c.close()" in.pdf in.docx
```

Its limits: headings are just bold text, footnotes lose their links, equations come out as loose characters, and it copies whatever the text layer says - so it must not be used on a PDF whose text layer failed the trust check.

### Scanned PDFs (and untrustworthy text layers)

The content has to be read from the image. Render the pages (`pdftoppm -r 150 -png in.pdf pages/p`) and read each one yourself with the Read tool, writing the Markdown as you go: this preserves equations, tables, sub/superscripts and any language, where OCR garbles all of them. For small print, crop the text region at higher resolution (220+ dpi) rather than reading a whole page; several strips can be stacked into one image. For long documents (more than ~30 pages) run OCR for the body text first (`pymupdf4llm.to_markdown` does this through Tesseract when installed), then go through the page images to correct it - always redo equations, tables and any non-English text by eye (check `tesseract --list-langs`; text in a language that is not installed comes out as nonsense).

Transcription is where errors creep in, so cross-check it with whatever independent evidence exists: any correct part of the text layer (every Latin word and number it holds should appear in your text), and for characters you were unsure of, a zoomed crop. Tell the user that the text was transcribed from page images, so names, numbers and rare characters deserve a second look.

## Looking at pages

```bash
mkdir -p pages && pdftoppm -r 100 -png in.pdf pages/p    # then Read pages/p-01.png ...
```

Use `-f N -l M` for a page range and `-r 150` when small print or subscripts matter. For a first overview of a long document, paste low-resolution pages into contact sheets (8 pages per image). For documents up to ~30 pages look at every page; for longer ones look at every page that has a table, figure or equation plus a sample of plain pages. To check a .docx or .md visually, convert it to PDF first.

## Verify

Run the check after every conversion. It prints `RESULT: OK` or `RESULT: CHECK` with the reasons.

```bash
python3 "$SKILL/scripts/losscheck.py" SOURCE OUTPUT [figures.json]
```

How to read it:
- The "missing" word list points at what was lost - search the source for those words to find the passage, table or reference that did not make it, and restore it. Missing numbers usually mean a table lost cells.
- When the source is a PDF, a little is expected to go (page numbers, running headers); that is why its threshold is lower. Pass `figures.json` when figures were cropped, otherwise every axis label counts as lost text.
- **The script only knows what its own readers can see in the source.** `?` marks what it cannot count: equations and tables inside a PDF, anything in a scan. A PDF with a broken text layer under-reports its own content, so the script can say OK while half the text is missing - which is why its font warning must be followed up by eye. Whenever a PDF is on either side, the script is not enough: look at the pages and confirm each equation, table and figure is present and correct.
- A PDF source reports tables and images as rough counts, so more in the output than in the source is normal.
- A warning that cannot be cleared (the source really is a scan, the fonts really have no Unicode map) is fine to finish on once the visual comparison has been done.

Only finish when the script is OK or every flagged item is explained, and the visual checks pass. If something truly cannot be carried over - an equation too degraded to read, a figure that cannot be cropped cleanly - keep it as an image of that region rather than dropping it, and tell the user.
