#!/usr/bin/env python3
"""losscheck.py SRC OUT [figures.json] - compare what a document held before and after conversion.
figures.json (optional) lists PDF regions kept as images, so the words inside them are not expected in OUT."""
import sys, re, json, subprocess, collections, zipfile, shutil

def tokens(text):
    return collections.Counter(re.findall(r"[a-z]{2,}|\d+(?:\.\d+)?|[㐀-鿿]", text.lower()))

def via_pandoc(path):
    fmt = "docx" if path.lower().endswith(".docx") else "markdown+tex_math_dollars"
    ast = json.loads(subprocess.run(["pandoc", "-f", fmt, "-t", "json", path],
                                    capture_output=True, text=True, check=True).stdout)
    inv = dict(text=[], extra="", headings=0, tables=0, images=0, equations=0, notes=[])
    def walk(x):
        if isinstance(x, list):
            for i in x: walk(i)
        elif isinstance(x, dict):
            t, c = x.get("t"), x.get("c")
            if t == "Str": inv["text"].append(c)
            elif t in ("Code", "CodeBlock"): inv["text"].append(c[1])
            elif t == "Math": inv["equations"] += 1; return
            elif t == "Header": inv["headings"] += 1
            elif t == "Table": inv["tables"] += 1
            elif t == "Image": inv["images"] += 1; return  # alt text repeats the caption
            elif t in ("RawBlock", "RawInline"):
                inv["tables"] += len(re.findall(r"<table\b", c[1]))
                inv["images"] += len(re.findall(r"<img\b", c[1]))
                inv["text"].append(re.sub(r"<[^>]+>", " ", c[1])); return
            for v in x.values(): walk(v)
    walk(ast["blocks"]); walk(ast.get("meta", {}))
    inv["text"] = " ".join(inv["text"])
    if fmt == "docx":  # read the raw XML too, so text pandoc skips (text boxes etc.) still counts as source
        z = zipfile.ZipFile(path)
        for n in z.namelist():
            if re.fullmatch(r"word/(document|footnotes|endnotes)\.xml", n):
                x = z.read(n).decode("utf8", "ignore")
                inv["extra"] += " " + " ".join(re.findall(r"<w:t(?: [^>]*)?>([^<]*)</w:t>", x))
                inv["checkboxes"] = inv.get("checkboxes", 0) + x.count("<w:checkBox>")
    return inv

def via_pdf(path, figs):
    import pymupdf
    doc = pymupdf.open(path)
    text, tables, images = [], 0, 0
    for i, page in enumerate(doc, 1):
        boxes = [pymupdf.Rect(f["rect"]) for f in figs if f["page"] == i]
        for x0, y0, x1, y1, word, *_ in page.get_text("words"):
            if not any(b.contains(pymupdf.Point((x0 + x1) / 2, (y0 + y1) / 2)) for b in boxes): text.append(word)
        images += len(page.get_images())
        try: tables += sum(1 for t in page.find_tables().tables
                           if not any(b.intersects(pymupdf.Rect(t.bbox)) for b in boxes))
        except Exception: pass
    text = " ".join(text)
    inv = dict(text=text, extra="", headings=None, tables=tables, images=images, equations=None, notes=[], pdf=True)
    if len(text.strip()) < 50 * len(doc):
        inv["notes"].append("scanned / image-only PDF: no usable text layer - check the page images by eye")
    elif shutil.which("pdffonts"):
        rows = subprocess.run(["pdffonts", path], capture_output=True, text=True).stdout.splitlines()[2:]
        bad = [r for r in rows if len(r.split()) >= 6 and r.split()[-3] == "no" and re.search(r"Custom|Identity", r)]
        if bad: inv["notes"].append(f"{len(bad)} font(s) have no Unicode map, so the PDF text layer may be garbled or "
                                    "missing whole scripts - compare extracted text with the page images")
    # PDFs hide structure: table/image counts are rough, so only large drops are worth a look.
    inv["images"] = None if figs or inv["notes"] else images
    return inv

def inventory(path, figs):
    p = path.lower()
    if p.endswith(".pdf"): return via_pdf(path, figs)
    if p.endswith(".txt"):
        return dict(text=open(path, encoding="utf-8-sig", errors="replace").read(), extra="", headings=None,
                    tables=None, images=None, equations=None, notes=[])
    return via_pandoc(path)

figs = json.load(open(sys.argv[3])) if len(sys.argv) > 3 else []
src, out = inventory(sys.argv[1], figs), inventory(sys.argv[2], [])
problems = [f"source: {n}" for n in src["notes"]] + [f"output: {n}" for n in out["notes"]]
a, b = tokens(src["text"] + " " + src["extra"]), tokens(out["text"] + " " + out["extra"])
# Distinct-word recall: a dropped section takes its unique words and numbers with it.
recall = sum(1 for w in a if w in b) / (len(a) or 1)
length = sum(tokens(out["text"]).values()) / (sum(tokens(src["text"]).values()) or 1)
limit = 0.92 if src.get("pdf") else 0.97
print(f"distinct words kept: {recall:.1%} of {len(a)}; length ratio: {length:.2f}")
boxes = lambda t: len(re.findall(r"[☐-☒]", t))
if src.get("checkboxes") and not out.get("pdf") and boxes(out["text"]) < boxes(src["extra"]) + src["checkboxes"]:
    problems.append(f"source has {src['checkboxes']} form checkboxes whose ticked/unticked state is missing from the output - run docx_prep.py first")
if not a:
    pass  # nothing readable in the source to compare against
elif recall < limit:
    gone = sorted((w for w in a if w not in b), key=lambda w: -a[w])[:25]
    problems.append(f"only {recall:.1%} of distinct words survived; missing: " + ", ".join(gone))
if length < 0.80:
    problems.append(f"output has only {length:.0%} of the source's word count - something may be truncated")
for key in ("headings", "tables", "images", "equations"):
    s, o = src[key], out[key]
    print(f"{key}: {s if s is not None else '?'} -> {o if o is not None else '?'}")
    if out.get("pdf") and key in ("tables", "images"): o = None  # cannot count these in a PDF reliably
    if s is not None and o is not None and o < s:
        problems.append(f"{key} dropped from {s} to {o}")
print("RESULT: " + ("OK" if not problems else "CHECK\n- " + "\n- ".join(problems)))
