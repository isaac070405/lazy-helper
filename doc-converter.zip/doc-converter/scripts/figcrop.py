#!/usr/bin/env python3
"""figcrop.py IN.pdf PAGE X0 Y0 X1 Y1 OUT.png - crop a region (PDF points, top-left origin) and log it."""
import sys, json, os, pymupdf
pdf, page, out = sys.argv[1], int(sys.argv[2]), sys.argv[7]
rect = [float(v) for v in sys.argv[3:7]]
os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
pymupdf.open(pdf)[page - 1].get_pixmap(clip=pymupdf.Rect(*rect), dpi=170).save(out)
log = "figures.json"
figs = json.load(open(log)) if os.path.exists(log) else []
figs.append({"page": page, "rect": rect}); json.dump(figs, open(log, "w"))
