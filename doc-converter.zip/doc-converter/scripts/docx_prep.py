#!/usr/bin/env python3
"""docx_prep.py IN.docx OUT.docx - report what pandoc cannot read in a Word file,
and write a copy in which form checkboxes are turned into plain ☐ / ☒ text."""
import sys, re, zipfile
src, dst = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(src); names = zin.namelist()
doc = zin.read("word/document.xml").decode("utf8")
count = [0, 0]
def box(m):
    run = m.group(0)
    if "<w:checkBox>" not in run: return run
    chk = re.search(r'<w:checked(?: w:val="([^"]*)")?/>', run)
    on = (chk.group(1) not in ("0", "false")) if chk else bool(re.search(r'<w:default w:val="(1|true)"/>', run))
    count[on] += 1
    return '<w:r><w:t xml:space="preserve">%s </w:t></w:r>' % ("☒" if on else "☐") + run
new = re.sub(r'<w:r\b(?:(?!</w:r>).)*?<w:fldChar w:fldCharType="begin">\s*<w:ffData>.*?</w:ffData>\s*</w:fldChar>\s*</w:r>',
             box, doc, flags=re.S)
with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        zout.writestr(item, new.encode("utf8") if item.filename == "word/document.xml" else zin.read(item.filename))
def has_text(prefix):
    return sum(1 for n in names if n.startswith(prefix) and re.search(r"<w:t[ >]", zin.read(n).decode("utf8", "ignore")))
report = {
    "form checkboxes (now written as text: unticked, ticked)": tuple(count),
    "text boxes / shapes with text": doc.count("<w:txbxContent"),
    "tracked insertions / deletions": (doc.count("<w:ins "), doc.count("<w:del ")),
    "comments": doc.count("<w:commentReference"),
    "headers / footers with text": has_text("word/header") + has_text("word/footer"),
    "charts / SmartArt / embedded objects": sum(n.startswith(("word/charts/", "word/diagrams/", "word/embeddings/")) for n in names),
    "dropdowns / other content controls": doc.count("<w:dropDownList") + doc.count("<w:comboBox") + doc.count("<w:ddList"),
    "equations": doc.count("<m:oMath>") + doc.count("<m:oMath "),
}
for k, v in report.items():
    if v and v != (0, 0): print(f"{k}: {v}")
print("docx_prep done ->", dst)
